<div class="my-3">
  <div class="col-12 col-lg-8 mx-auto">
    <div class="col-12 mx-auto">
      <form class="" action="data/login.php" method="post">
        <div class="row">
          <div class="col-12 col-lg-7 mx-auto">
            <img src="../images/res/login.png" alt="" class="img-fluid">
          </div>
          <div class="col-12 col-lg-6 mx-auto">
            <div class="row">
              <div class="form-group col-12">
                <label for="" class="text-primary h6">User ID</label>
                <input type="text" name="idno" value="" class="form-control text-primary h6">
              </div>
              <div class="form-group col-12">
                <label for="" class="text-primary h6">Password</label>
                <input type="password" name="password" value="" class="form-control text-primary h6">
              </div>
              <div class="col-12 col-lg-5 mx-auto form-group">
                <input type="submit" name="login" value="Log in" class="btn btn-primary btn-block">
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>
