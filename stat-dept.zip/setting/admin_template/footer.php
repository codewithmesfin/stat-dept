
<!-- Footer---->
<div class="card bg-success">
  <div class="col-12 col-lg-6 my-5 mx-auto">
    <footer>
      <ul class="nav flex-column flex-sm-row">
        <li class="nav-item">
          <a href="#" class="text-white nav-link">Home</a>
        </li>
        <li class="nav-item">
          <a href="#" class="text-white nav-link">Terms</a>
        </li>
        <li class="nav-item">
          <a href="#" class="text-white nav-link">About</a>
        </li>
        <li class="nav-item">
          <a href="#" class="text-white nav-link">Programs</a>
        </li>
        <li class="nav-item">
          <a href="#" class="text-white nav-link">Contact us</a>
        </li>
        <li class="nav-item">
          <a href="#" class="text-white nav-link" data-toggle="modal" data-target=".bd-example-modal-sm">Logout</a>
        </li>
      </ul>
      <p class="text-center">&copy All rights reserved! <a href="#" data-toggle="modal" data-target="#modalYT">Developers</a> </p>
    </footer>
  </div>
</div>
<!-- Footer---->
