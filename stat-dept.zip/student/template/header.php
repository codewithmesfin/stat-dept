<div class="container rounded-top" style="background-color:white">
  <div class="d-none d-md-block">
    <div class="page_header col-12" style="background:white;">
      <div class="row">
        <div class="col-5 offset-md-1">
          <img src="../images/aau1.png" style="height:90px">
        </div>
        <div class="col-4 mx-auto my-2">
          <img src="../images/stat.jpg" alt="" class="img-fluid float-right" style="height:70px;">
        </div>
      </div>
    </div>
  </div>
  </div>

</div>
