
<!-- Footer---->
<div class="container card bg-primary">
  <div class="col-12 col-lg-6 my-3 mx-auto">
    <footer>
      <ul class="nav flex-column flex-sm-row">
        <li class="nav-item">
          <a href="#" class="text-white nav-link">Home</a>
        </li>
        <li class="nav-item">
          <a href="#" class="text-white nav-link">Terms</a>
        </li>
        <li class="nav-item">
          <a href="#" class="text-white nav-link">About</a>
        </li>
        <li class="nav-item">
          <a href="#" class="text-white nav-link">Programs</a>
        </li>
        <li class="nav-item">
          <a href="#" class="text-white nav-link">Contact us</a>
        </li>
        <li class="nav-item">
          <a href="../data/logout.php" class="text-white nav-link">Logout</a>
        </li>
      </ul>
      <p class="text-center">&copy All rights reserved! <a href="#" data-toggle="modal" data-target="#teacher" class="text-white" ><strong>Developers</strong> </a> </p>
    </footer>
  </div>
</div>
<!-- Footer---->
